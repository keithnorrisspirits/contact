# Keith Norris — Trade Show Contact Kit

This folder contains a one-scan page to save your contact, view your CV, and connect on LinkedIn.

**What to do next**
1) Host this folder on GitHub Pages/Netlify/Vercel or your domain. Point an easy URL at it.
2) Once live, regenerate `qr.png` to the live URL so the QR opens the page rather than LinkedIn.
3) Add the QR to your badge and phone lock screen; consider a Wallet pass via a digital card app for instant access.
4) Optional: add a calendar booking link to `index.html` later.

QR points to your LinkedIn profile for immediate connect.
